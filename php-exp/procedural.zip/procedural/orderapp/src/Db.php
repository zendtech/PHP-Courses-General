<?php
/**
 * Database Functions (connection and query builders)
 */

/**
 * Connect to the database
 * @param array $config
 * @return mysqli
 */
function getDbConnection(array $config): mysqli {
    return mysqli_connect($config['dsn'], $config['username'], $config['password'], $config['database']);
}

/**
 * @param array $values
 * @return string|null
 */
function getWhere(array $values): ?string {
    $where = false;

    // If only one element, return a single where
    if (count($values) === 1) {
        $key = key($values);
        $value = current($values);
        if($value) return $where . " WHERE $key = '$value'";
        return $where;
    }

    // If multiples wheres, build them.
    for ($i = 1; $i <= count($values); $i++) {
        $key = key($values);
        $value = current($values);
        if ($i === 1 && $value) {
            $where .= " WHERE $key = '$value'";
            next($values);
            continue;
        }
        if($value) $where .= " AND $key = '$value'";
        next($values);
    }
    return $where;
}

/**
 * @param $conn
 * @param string $table
 * @return array
 */
function getColumns($conn, string $table): array {
    $columnQuery = "select distinct Column_name from Information_schema.columns where Table_name = '$table'";
    $result = mysqli_query($conn, $columnQuery);
    $results = $result->fetch_all(MYSQLI_NUM);
    $columns = [];
    foreach ($results as $value) {
        $columns[] = current($value);
    }
    return $columns;
}