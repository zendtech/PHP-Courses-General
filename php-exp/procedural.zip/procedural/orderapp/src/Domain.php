<?php
/**
 * Domain Functions (Functions that are Domain-specific, or business logic functions)
 */

/**
 * @param $config
 * @param $selectedStatus
 * @return string
 */
function getStatusSelect(array $config, string $selectedStatus): string {
    // Alphabetize
    sort($config['status_codes']);
    return getSelectHTML($config['status_codes'], $selectedStatus, true, 'status_filter');
}

/**
 * @param $conn
 * @return string
 */
function getCustomersSelect($conn): string {
    $list = [];
    foreach(getCustomers($conn) as $key => $customer){
        $list[$customer[0]] = next($customer);
    }
    return getSelectHTML($list, null, false, 'customer');
}

/**
 * @param float $amount
 * @param string $currency
 * @return string
 */
function formatCurrency(float $amount, string $currency = '$'): string {
    return $currency . number_format($amount, 0, '.', ',');
}